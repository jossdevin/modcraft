import { world as World } from "@minecraft/server"
import {
    ActionFormData,
    ModalFormData
} from "@minecraft/server-ui"

function getScore(objective, player) {
    try {
        const command = player.runCommand(`scoreboard players test @s "${objective}" * *`)
        return parseInt(command.statusMessage.split(/\s+/)[1])
    } catch {
        return 0
    }
}
//Settings App
export function BlackCellphoneformSettingsApp(player, lore) {
    let functions = []
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_settings`)
    actionForm.body(`${lore[2]}%`)
    {
        actionForm.button("button.back", "textures/icons_apps/back.png")
        functions.push(r => {
            BlackCellphoneForm(player, lore)
        })
    }
    if (!player.hasTag("want_notific")) {
        actionForm.button("button.enable_notific", "textures/icons_apps/notific_off.png")
        functions.push(r => {
            player.runCommand("tag @s add want_notific")
            BlackCellphoneformSettingsApp(player, lore)
        })
    }
    if (player.hasTag("want_notific")) {
        actionForm.button("button.disable_notific", "textures/icons_apps/notific_on.png")
        functions.push(r => {
            player.runCommand("tag @s remove want_notific")
            BlackCellphoneformSettingsApp(player, lore)
        })
    }
    actionForm.show(player).then(r => {
        functions[r.selection]()
    })
}
//AppStore App
export function BlackCellphoneformAppStoreApp(player, lore) {
    let actionForm = new ActionFormData()
    const store_purchased_purchase = []
    if (player.hasTag('store_app')) {
        store_purchased_purchase.push("purchased")
    }
    if (!player.hasTag('store_app')) {
        store_purchased_purchase.push("purchase")
    }
    const bank_purchased_purchase = []
    if (player.hasTag('bank_app')) {
        bank_purchased_purchase.push("purchased")
    }
    if (!player.hasTag('bank_app')) {
        bank_purchased_purchase.push("purchase")
    }
    const music_purchased_purchase = []
    if (player.hasTag('music_app')) {
        music_purchased_purchase.push("purchased")
    }
    if (!player.hasTag('music_app')) {
        music_purchased_purchase.push("purchase")
    }
    const daynight_purchased_purchase = []
    if (player.hasTag('daynight_app')) {
        daynight_purchased_purchase.push("purchased")
    }
    if (!player.hasTag('daynight_app')) {
        daynight_purchased_purchase.push("purchase")
    }
    const weather_purchased_purchase = []
    if (player.hasTag('weather_app')) {
        weather_purchased_purchase.push("purchased")
    }
    if (!player.hasTag('weather_app')) {
        weather_purchased_purchase.push("purchase")
    }
    const effect_purchased_purchase = []
    if (player.hasTag('effect_app')) {
        effect_purchased_purchase.push("purchased")
    }
    if (!player.hasTag('effect_app')) {
        effect_purchased_purchase.push("purchase")
    }
    const discraft_purchased_purchase = []
    if (player.hasTag('discraft_app')) {
        discraft_purchased_purchase.push("purchased")
    }
    if (!player.hasTag('discraft_app')) {
        discraft_purchased_purchase.push("purchase")
    }
    actionForm.title(`title.smartphone_appstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back_full.png")
    actionForm.button(`button.store_app_${store_purchased_purchase}`, `textures/icons_apps/app_store/store_${store_purchased_purchase}.png`)
    actionForm.button(`button.bank_app_${bank_purchased_purchase}`, `textures/icons_apps/app_store/bank_${bank_purchased_purchase}.png`)
    actionForm.button(`button.music_app_${music_purchased_purchase}`, `textures/icons_apps/app_store/music_${music_purchased_purchase}.png`)
    actionForm.button(`button.daynight_app_${daynight_purchased_purchase}`, `textures/icons_apps/app_store/daynight_${daynight_purchased_purchase}.png`)
    actionForm.button(`button.weather_app_${weather_purchased_purchase}`, `textures/icons_apps/app_store/weather_${weather_purchased_purchase}.png`)
    actionForm.button(`button.effect_app_${effect_purchased_purchase}`, `textures/icons_apps/app_store/effect_${effect_purchased_purchase}.png`)
    actionForm.button(`button.discraft_app_${discraft_purchased_purchase}`, `textures/icons_apps/app_store/discraft_${discraft_purchased_purchase}.png`)
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneForm(player, lore)
        }
        if (selection == 1) {
            if (player.hasTag('store_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_already_have_this_app"}]}`)
            }
            if (getScore('money', player) < 15 && !player.hasTag('store_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 14 && !player.hasTag('store_app')) {
                player.runCommand(`tag @s add store_app`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.app_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 15`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformAppStoreApp(player, lore)
            }
        }
        if (selection == 2) {
            if (player.hasTag('bank_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_already_have_this_app"}]}`)
            }
            if (!player.hasTag('bank_app')) {
                player.runCommand(`tag @s add bank_app`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.app_purchased_sucessfully"}]}`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformAppStoreApp(player, lore)
            }
        }
        if (selection == 3) {
            if (player.hasTag('music_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_already_have_this_app"}]}`)
            }
            if (getScore('money', player) < 20 && !player.hasTag('music_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 19 && !player.hasTag('music_app')) {
                player.runCommand(`tag @s add music_app`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.app_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 20`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformAppStoreApp(player, lore)
            }
        }
        if (selection == 4) {
            if (player.hasTag('daynight_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_already_have_this_app"}]}`)
            }
            if (getScore('money', player) < 50 && !player.hasTag('daynight_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 49 && !player.hasTag('daynight_app')) {
                player.runCommand(`tag @s add daynight_app`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.app_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 50`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformAppStoreApp(player, lore)
            }
        }
        if (selection == 5) {
            if (player.hasTag('weather_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_already_have_this_app"}]}`)
            }
            if (getScore('money', player) < 50 && !player.hasTag('weather_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 49 && !player.hasTag('weather_app')) {
                player.runCommand(`tag @s add weather_app`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.app_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 50`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformAppStoreApp(player, lore)
            }
        }
        if (selection == 6) {
            if (player.hasTag('effect_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_already_have_this_app"}]}`)
            }
            if (getScore('money', player) < 25 && !player.hasTag('effect_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 24 && !player.hasTag('effect_app')) {
                player.runCommand(`tag @s add effect_app`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.app_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 25`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformAppStoreApp(player, lore)
            }
        }
        if (selection == 7) {
            if (player.hasTag('discraft_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_already_have_this_app"}]}`)
            }
            if (getScore('money', player) < 25 && !player.hasTag('discraft_app')) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 24 && !player.hasTag('discraft_app')) {
                player.runCommand(`tag @s add discraft_app`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.app_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 25`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformAppStoreApp(player, lore)
            }
        }
    })
}
//Store App
export function BlackCellphoneformStoreItemsFoodsApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.beef_cooked", "textures/items/beef_cooked.png")
    actionForm.button("button.mutton_cooked", "textures/items/mutton_cooked.png")
    actionForm.button("button.chicken_cooked", "textures/items/chicken_cooked.png")
    actionForm.button("button.rabbit_cooked", "textures/items/rabbit_cooked.png")
    actionForm.button("button.porkchop_cooked", "textures/items/porkchop_cooked.png")
    actionForm.button("button.fish_cooked", "textures/items/fish_cooked.png")
    actionForm.button("button.fish_salmon_cooked", "textures/items/fish_salmon_cooked.png")
    actionForm.button("button.mushroom_stew", "textures/items/mushroom_stew.png")
    actionForm.button("button.rabbit_stew", "textures/items/rabbit_stew.png")
    actionForm.button("button.beetroot_soup", "textures/items/beetroot_soup.png")
    actionForm.button("button.potato_baked", "textures/items/potato_baked.png")
    actionForm.button("button.cookie", "textures/items/cookie.png")
    actionForm.button("button.pumpkin_pie", "textures/items/pumpkin_pie.png")
    actionForm.button("button.apple", "textures/items/apple.png")
    actionForm.button("button.cake", "textures/items/cake.png")
    actionForm.button("button.bread", "textures/items/bread.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s cooked_beef`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s cooked_mutton`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s cooked_chicken`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s cooked_rabbit`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 5) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s cooked_porkchop`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 6) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s cooked_cod`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 7) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s cooked_salmon`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 8) {
            if (getScore('money', player) < 10) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 9) {
                player.runCommand(`give @s mushroom_stew`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 10`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 9) {
            if (getScore('money', player) < 10) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 9) {
                player.runCommand(`give @s rabbit_stew`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 10`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 10) {
            if (getScore('money', player) < 10) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 9) {
                player.runCommand(`give @s beetroot_soup`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 10`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 11) {
            if (getScore('money', player) < 2) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 1) {
                player.runCommand(`give @s baked_potato`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 2`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 12) {
            if (getScore('money', player) < 2) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 1) {
                player.runCommand(`give @s cookie`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 2`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 13) {
            if (getScore('money', player) < 20) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 19) {
                player.runCommand(`give @s pumpkin_pie`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 20`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 14) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s apple`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 15) {
            if (getScore('money', player) < 20) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 19) {
                player.runCommand(`give @s cake`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 20`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
        if (selection == 16) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s bread`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsFoodsApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsDropsApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.rotten_flesh", "textures/items/rotten_flesh.png")
    actionForm.button("button.bone", "textures/items/bone.png")
    actionForm.button("button.spider_eye", "textures/items/spider_eye.png")
    actionForm.button("button.string", "textures/items/string.png")
    actionForm.button("button.gunpowder", "textures/items/gunpowder.png")
    actionForm.button("button.blaze_rod", "textures/items/blaze_rod.png")
    actionForm.button("button.magma_cream", "textures/items/magma_cream.png")
    actionForm.button("button.ender_pearl", "textures/items/ender_pearl.png")
    actionForm.button("button.phantom_membrane", "textures/items/phantom_membrane.png")
    actionForm.button("button.slime_ball", "textures/items/slimeball.png")
    actionForm.button("button.ghast_tear", "textures/items/ghast_tear.png")
    actionForm.button("button.feather", "textures/items/feather.png")
    actionForm.button("button.shulker_shell", "textures/items/shulker_shell.png")
    actionForm.button("button.leather", "textures/items/leather.png")
    actionForm.button("button.rabbit_hide", "textures/items/rabbit_hide.png")
    actionForm.button("button.rabbit_foot", "textures/items/rabbit_foot.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 1) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 0) {
                player.runCommand(`give @s rotten_flesh`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 1`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 1) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 0) {
                player.runCommand(`give @s bone`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 1`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s spider_eye`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 2) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 1) {
                player.runCommand(`give @s string`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 2`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 5) {
            if (getScore('money', player) < 10) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 9) {
                player.runCommand(`give @s gunpowder`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 10`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 6) {
            if (getScore('money', player) < 20) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 19) {
                player.runCommand(`give @s blaze_rod`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 20`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 7) {
            if (getScore('money', player) < 15) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 14) {
                player.runCommand(`give @s magma_cream`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 15`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 8) {
            if (getScore('money', player) < 10) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 9) {
                player.runCommand(`give @s ender_pearl`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 10`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 9) {
            if (getScore('money', player) < 50) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 49) {
                player.runCommand(`give @s phantom_membrane`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 50`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 10) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s slime_ball`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 11) {
            if (getScore('money', player) < 20) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 19) {
                player.runCommand(`give @s ghast_tear`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 20`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 12) {
            if (getScore('money', player) < 2) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 1) {
                player.runCommand(`give @s feather`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 2`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 13) {
            if (getScore('money', player) < 100) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 99) {
                player.runCommand(`give @s shulker_shell`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 100`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 14) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s leather`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 15) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s rabbit_hide`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
        if (selection == 16) {
            if (getScore('money', player) < 5) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 4) {
                player.runCommand(`give @s rabbit_stew`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 5`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsDropsApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsArmorsIronApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.iron_helmet", "textures/items/iron_helmet.png")
    actionForm.button("button.iron_chestplate", "textures/items/iron_chestplate.png")
    actionForm.button("button.iron_leggings", "textures/items/iron_leggings.png")
    actionForm.button("button.iron_boots", "textures/items/iron_boots.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsArmorsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 50) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 49) {
                player.runCommand(`give @s iron_helmet`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 50`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsIronApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 80) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 79) {
                player.runCommand(`give @s iron_chestplate`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 80`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsIronApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 70) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 69) {
                player.runCommand(`give @s iron_leggings`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 70`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsIronApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 40) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 39) {
                player.runCommand(`give @s iron_boots`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 40`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsIronApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsArmorsGoldApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.gold_helmet", "textures/items/gold_helmet.png")
    actionForm.button("button.gold_chestplate", "textures/items/gold_chestplate.png")
    actionForm.button("button.gold_leggings", "textures/items/gold_leggings.png")
    actionForm.button("button.gold_boots", "textures/items/gold_boots.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsArmorsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 125) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 124) {
                player.runCommand(`give @s golden_helmet`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 125`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsGoldApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 200) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 199) {
                player.runCommand(`give @s golden_chestplate`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 200`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsGoldApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 175) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 174) {
                player.runCommand(`give @s golden_leggings`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 175`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsGoldApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 100) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 99) {
                player.runCommand(`give @s golden_boots`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 100`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsGoldApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsArmorsDiamondApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.diamond_helmet", "textures/items/diamond_helmet.png")
    actionForm.button("button.diamond_chestplate", "textures/items/diamond_chestplate.png")
    actionForm.button("button.diamond_leggings", "textures/items/diamond_leggings.png")
    actionForm.button("button.diamond_boots", "textures/items/diamond_boots.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsArmorsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 250) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 249) {
                player.runCommand(`give @s diamond_helmet`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 250`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsDiamondApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 400) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 399) {
                player.runCommand(`give @s diamond_chestplate`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 400`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsDiamondApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 350) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 349) {
                player.runCommand(`give @s diamond_leggings`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 350`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsDiamondApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 200) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 199) {
                player.runCommand(`give @s diamond_boots`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 200`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsDiamondApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsArmorsNetheriteApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.netherite_helmet", "textures/items/netherite_helmet.png")
    actionForm.button("button.netherite_chestplate", "textures/items/netherite_chestplate.png")
    actionForm.button("button.netherite_leggings", "textures/items/netherite_leggings.png")
    actionForm.button("button.netherite_boots", "textures/items/netherite_boots.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsArmorsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 2500) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 2499) {
                player.runCommand(`give @s netherite_helmet`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 2500`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsNetheriteApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 4000) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 3999) {
                player.runCommand(`give @s netherite_chestplate`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 4000`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsNetheriteApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 3500) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 3499) {
                player.runCommand(`give @s netherite_leggings`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 3500`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsNetheriteApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 2000) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 1999) {
                player.runCommand(`give @s netherite_boots`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 2000`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsArmorsNetheriteApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsArmorsApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.iron_armor", "textures/items/iron_chestplate.png")
    actionForm.button("button.gold_armor", "textures/items/gold_chestplate.png")
    actionForm.button("button.diamond_armor", "textures/items/diamond_chestplate.png")
    actionForm.button("button.netherite_armor", "textures/items/netherite_chestplate.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsApp(player, lore)
        }
        if (selection == 1) {
            BlackCellphoneformStoreItemsArmorsIronApp(player, lore)
        }
        if (selection == 2) {
            BlackCellphoneformStoreItemsArmorsGoldApp(player, lore)
        }
        if (selection == 3) {
            BlackCellphoneformStoreItemsArmorsDiamondApp(player, lore)
        }
        if (selection == 4) {
            BlackCellphoneformStoreItemsArmorsNetheriteApp(player, lore)
        }
    })
}
export function BlackCellphoneformStoreItemsWeaponsIronApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.iron_sword", "textures/items/iron_sword.png")
    actionForm.button("button.iron_pickaxe", "textures/items/iron_pickaxe.png")
    actionForm.button("button.iron_axe", "textures/items/iron_axe.png")
    actionForm.button("button.iron_shovel", "textures/items/iron_shovel.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsWeaponsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 20) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 19) {
                player.runCommand(`give @s iron_sword`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 20`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsIronApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 30) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 29) {
                player.runCommand(`give @s iron_pickaxe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 39`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsIronApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 30) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 29) {
                player.runCommand(`give @s iron_axe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 30`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsIronApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 20) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 19) {
                player.runCommand(`give @s iron_shovel`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 20`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsIronApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsWeaponsGoldApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.gold_sword", "textures/items/gold_sword.png")
    actionForm.button("button.gold_pickaxe", "textures/items/gold_pickaxe.png")
    actionForm.button("button.gold_axe", "textures/items/gold_axe.png")
    actionForm.button("button.gold_shovel", "textures/items/gold_shovel.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsWeaponsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 50) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 39) {
                player.runCommand(`give @s golden_sword`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 50`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsGoldApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 75) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 74) {
                player.runCommand(`give @s golden_pickaxe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 75`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsGoldApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 75) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 74) {
                player.runCommand(`give @s golden_axe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 75`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsGoldApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 50) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 49) {
                player.runCommand(`give @s golden_shovel`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 50`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsGoldApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsWeaponsDiamondApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.diamond_sword", "textures/items/diamond_sword.png")
    actionForm.button("button.diamond_pickaxe", "textures/items/diamond_pickaxe.png")
    actionForm.button("button.diamond_axe", "textures/items/diamond_axe.png")
    actionForm.button("button.diamond_shovel", "textures/items/diamond_shovel.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsWeaponsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 100) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 99) {
                player.runCommand(`give @s diamond_sword`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 100`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsDiamondApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 150) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 149) {
                player.runCommand(`give @s diamond_pickaxe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 150`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsDiamondApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 150) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 149) {
                player.runCommand(`give @s diamond_axe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 150`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsDiamondApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 100) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 99) {
                player.runCommand(`give @s diamond_shovel`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 100`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsDiamondApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsWeaponsNetheriteApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.netherite_sword", "textures/items/netherite_sword.png")
    actionForm.button("button.netherite_pickaxe", "textures/items/netherite_pickaxe.png")
    actionForm.button("button.netherite_axe", "textures/items/netherite_axe.png")
    actionForm.button("button.netherite_shovel", "textures/items/netherite_shovel.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreItemsWeaponsApp(player, lore)
        }
        if (selection == 1) {
            if (getScore('money', player) < 1000) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 999) {
                player.runCommand(`give @s netherite_sword`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 1000`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsNetheriteApp(player, lore)
            }
        }
        if (selection == 2) {
            if (getScore('money', player) < 1500) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 1499) {
                player.runCommand(`give @s netherite_pickaxe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 1500`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsNetheriteApp(player, lore)
            }
        }
        if (selection == 3) {
            if (getScore('money', player) < 1500) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 1499) {
                player.runCommand(`give @s netherite_axe`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 1500`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsNetheriteApp(player, lore)
            }
        }
        if (selection == 4) {
            if (getScore('money', player) < 1000) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.not_enought_money"}]}`)
            }
            if (getScore('money', player) > 999) {
                player.runCommand(`give @s netherite_shovel`)
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.item_purchased_sucessfully"}]}`)
                player.runCommand(`scoreboard players remove @s money 1000`)
                player.runCommand(`playsound random.levelup @s ~~~ 1 1`)
                BlackCellphoneformStoreItemsWeaponsNetheriteApp(player, lore)
            }
        }
    })
}
export function BlackCellphoneformStoreItemsWeaponsApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.iron_weapons", "textures/items/iron_sword.png")
    actionForm.button("button.gold_weapons", "textures/items/gold_sword.png")
    actionForm.button("button.diamond_weapons", "textures/items/diamond_sword.png")
    actionForm.button("button.netherite_weapons", "textures/items/netherite_sword.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreApp(player, lore)
        }
        if (selection == 1) {
            BlackCellphoneformStoreItemsWeaponsIronApp(player, lore)
        }
        if (selection == 2) {
            BlackCellphoneformStoreItemsWeaponsGoldApp(player, lore)
        }
        if (selection == 3) {
            BlackCellphoneformStoreItemsWeaponsDiamondApp(player, lore)
        }
        if (selection == 4) {
            BlackCellphoneformStoreItemsWeaponsNetheriteApp(player, lore)
        }
    })
}
export function BlackCellphoneformStoreItemsApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_itemsstore§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.foods", "textures/icons_apps/store_app/foods.png")
    actionForm.button("button.drops", "textures/icons_apps/store_app/drops.png")
    actionForm.button("button.armors", "textures/icons_apps/store_app/armors.png")
    actionForm.button("button.weapons", "textures/icons_apps/store_app/weapons.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformStoreApp(player, lore)
        }
        if (selection == 1) {
            BlackCellphoneformStoreItemsFoodsApp(player, lore)
        }
        if (selection == 2) {
            BlackCellphoneformStoreItemsDropsApp(player, lore)
        }
        if (selection == 3) {
            BlackCellphoneformStoreItemsArmorsApp(player, lore)
        }
        if (selection == 4) {
            BlackCellphoneformStoreItemsWeaponsApp(player, lore)
        }
    })
}
export function BlackCellphoneformStoreApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_store§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.items", "textures/ui/icon_recipe_item.png")
    actionForm.button("button.blocks", "textures/ui/icon_recipe_construction.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneForm(player, lore)
        }
        if (selection == 1) {
            BlackCellphoneformStoreItemsApp(player, lore)
        }
        if (selection == 2) {
            player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.coming_soon"}]}`)
        }
    })
}
//Bank App
export function BlackCellphoneformBankTransferApp(player, lore) {
    let form = new ModalFormData()
    let playerNameList = Array.from(World.getPlayers(), plr => plr.nameTag)
    form.title(`title.smartphone_bank` + ` ${lore[2]}%`)
    form.dropdown("text.players_online", playerNameList)
    form.textField("text.quantity", "text.type_here")
    form.show(player).then((response) => {
        if (response.formValues[1]) {
            if (response.formValues[1] < 0) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_cant_send_negative_money"}]}`)
            }
            if (playerNameList[response.formValues[0]] == player.nameTag && response.formValues[1] > 0) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_cant_send_money_to_yourself"}]}`)
            } else {
                if (getScore('money', player) < response.formValues[1] && response.formValues[1] > 0) {
                    player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_dont_have_money"}]}`)
                }
                if (getScore('money', player) >= response.formValues[1] && response.formValues[1] > 0) {
                    player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.transfer_sucessfull"}]}`)
                    player.runCommand(`scoreboard players remove @s money ${response.formValues[1]}`)
                    player.runCommand(`scoreboard players add ${playerNameList[response.formValues[0]]} money ${response.formValues[1]}`)
                    player.runCommand(`execute ${playerNameList[response.formValues[0]]} ~~~ playsound random.notification @s[hasitem={item=smartphone:black_smartphone}, tag=want_notific] ~~~ 1 1`)
                    player.runCommand(`execute ${playerNameList[response.formValues[0]]} ~~~ titleraw @s[hasitem={item=smartphone:black_smartphone}, tag=want_notific] actionbar {"rawtext":[{"translate":"text_smartphoneaddon.message"},{"text":"\n"},{"text":" ${player.nameTag} "},{"translate":"text_smartphoneaddon.made_a_transfer"},{"text":" §2$${response.formValues[1]} "},{"translate":"text_smartphoneaddon.for_you"}]}`)
                }
            }
        }
    })
}
export function BlackCellphoneformBankDepositeApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_deposite§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.iron_ingot", "textures/items/iron_ingot.png")
    actionForm.button("button.gold_ingot", "textures/items/gold_ingot.png")
    actionForm.button("button.diamond", "textures/items/diamond.png")
    actionForm.button("button.emerald", "textures/items/emerald.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            player.runCommand(`function sell_iron_ingot`)
            BlackCellphoneformBankDepositeApp(player, lore)
        }
        if (selection == 1) {
            player.runCommand(`function sell_gold_ingot`)
            BlackCellphoneformBankDepositeApp(player, lore)
        }
        if (selection == 2) {
            player.runCommand(`function sell_diamond`)
            BlackCellphoneformBankDepositeApp(player, lore)
        }
        if (selection == 3) {
            player.runCommand(`function sell_emerald`)
            BlackCellphoneformBankDepositeApp(player, lore)
        }
    })
}
export function BlackCellphoneformBankApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_bank§2$${getScore('money', player)}`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.transfer_money", "textures/icons_apps/transfer.png")
    actionForm.button("button.deposite_money", "textures/icons_apps/deposite.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneForm(player, lore)
        }
        if (selection == 1) {
            BlackCellphoneformBankTransferApp(player, lore)
        }
        if (selection == 2) {
            BlackCellphoneformBankDepositeApp(player, lore)
        }
    })
}
//Spotcraft App
export function BlackCellphoneformMusicAppAlbum1(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_music`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.stop_music", "textures/icons_apps/cancel.png")
    actionForm.button("Pigstep\n§8Lena Raine", "textures/items/record_pigstep.png")
    actionForm.button("Thirteen (Disc 13)\n§8C418", "textures/items/record_13.png")
    actionForm.button("Cat\n§8C418", "textures/items/record_cat.png")
    actionForm.button("Blocks\n§8C418", "textures/items/record_blocks.png")
    actionForm.button("Chirp\n§8C418", "textures/items/record_chirp.png")
    actionForm.button("Far\n§8C418", "textures/items/record_far.png")
    actionForm.button("Mall\n§8C418", "textures/items/record_mall.png")
    actionForm.button("Mellohi\n§8C418", "textures/items/record_mellohi.png")
    actionForm.button("Stal\n§8C418", "textures/items/record_stal.png")
    actionForm.button("Strad\n§8C418", "textures/items/record_strad.png")
    actionForm.button("Ward\n§8C418", "textures/items/record_ward.png")
    actionForm.button("Wait\n§8C418", "textures/items/record_wait.png")
    actionForm.button("Otherside\n§8Lena Raine", "textures/items/record_otherside.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneformMusicApp(player, lore)
        }
        if (selection == 1) {
            player.runCommand("stopsound @s")
        }
        if (selection == 2) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.pigstep @s")
        }
        if (selection == 3) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.13 @s")
        }
        if (selection == 4) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.cat @s")
        }
        if (selection == 5) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.blocks @s")
        }
        if (selection == 6) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.chirp @s")
        }
        if (selection == 7) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.far @s")
        }
        if (selection == 8) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.mall @s")
        }
        if (selection == 9) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.mellohi @s")
        }
        if (selection == 10) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.stal @s")
        }
        if (selection == 11) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.strad @s")
        }
        if (selection == 12) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.ward @s")
        }
        if (selection == 13) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.wait @s")
        }
        if (selection == 14) {
            player.runCommand("stopsound @s")
            player.runCommand("playsound record.otherside @s")
        }
    })
}
export function BlackCellphoneformMusicApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_music`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("Minecraft Musics\n§8C418, Lena Raine... - Album", "textures/icons_apps/music_app/minecraft_volume_alpha.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneForm(player, lore)
        }
        if (selection == 1) {
            BlackCellphoneformMusicAppAlbum1(player, lore)
        }
    })
}
//DayNight App
export function BlackCellphoneformDayNightApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_daynight`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.midnight", "textures/icons_apps/day_night_app/midnight.png")
    actionForm.button("button.night", "textures/icons_apps/day_night_app/night.png")
    actionForm.button("button.sunset", "textures/icons_apps/day_night_app/sunset.png")
    actionForm.button("button.noon", "textures/icons_apps/day_night_app/noon.png")
    actionForm.button("button.sunrise", "textures/icons_apps/day_night_app/sunrise.png")
    actionForm.button("button.day", "textures/icons_apps/day_night_app/day.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneForm(player, lore)
        }
        if (selection == 1) {
            player.runCommand("time set midnight")
            BlackCellphoneformDayNightApp(player, lore)
        }
        if (selection == 2) {
            player.runCommand("time set night")
            BlackCellphoneformDayNightApp(player, lore)
        }
        if (selection == 3) {
            player.runCommand("time set sunset")
            BlackCellphoneformDayNightApp(player, lore)
        }
        if (selection == 4) {
            player.runCommand("time set noon")
            BlackCellphoneformDayNightApp(player, lore)
        }
        if (selection == 5) {
            player.runCommand("time set sunrise")
            BlackCellphoneformDayNightApp(player, lore)
        }
        if (selection == 6) {
            player.runCommand("time set day")
            BlackCellphoneformDayNightApp(player, lore)
        }
    })
}
//Weather App
export function BlackCellphoneformWeatherApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_weather`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.clear", "textures/icons_apps/weather_app/clear.png")
    actionForm.button("button.rain", "textures/icons_apps/weather_app/rain.png")
    actionForm.button("button.storm", "textures/icons_apps/weather_app/storm.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneForm(player, lore)
        }
        if (selection == 1) {
            player.runCommand("weather clear")
            BlackCellphoneformWeatherApp(player, lore)
        }
        if (selection == 2) {
            player.runCommand("weather rain")
            BlackCellphoneformWeatherApp(player, lore)
        }
        if (selection == 3) {
            player.runCommand("weather thunder")
            BlackCellphoneformWeatherApp(player, lore)
        }
    })
}
//Effect App
export function BlackCellphoneformEffectApp(player, lore) {
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_effect`)
    actionForm.body(`${lore[2]}%`)
    actionForm.button("button.back", "textures/icons_apps/back.png")
    actionForm.button("button.regeneration", "textures/ui/regeneration_effect.png")
    actionForm.button("button.speed", "textures/ui/speed_effect.png")
    actionForm.button("button.jump_boost", "textures/ui/jump_boost_effect.png")
    actionForm.button("button.haste", "textures/ui/haste_effect.png")
    actionForm.button("button.night_vision", "textures/ui/night_vision_effect.png")
    actionForm.button("button.water_breathing", "textures/ui/water_breathing_effect.png")
    actionForm.show(player).then(actionFormResponse => {
        const { selection } = actionFormResponse
        if (selection == 0) {
            BlackCellphoneForm(player, lore)
        }
        if (selection == 1) {
            player.runCommand("effect @s regeneration 30 5")
            BlackCellphoneformEffectApp(player, lore)
        }
        if (selection == 2) {
            player.runCommand("effect @s speed 30 5")
            BlackCellphoneformEffectApp(player, lore)
        }
        if (selection == 3) {
            player.runCommand("effect @s jump_boost 30 5")
            BlackCellphoneformEffectApp(player, lore)
        }
        if (selection == 4) {
            player.runCommand("effect @s haste 30 5")
            BlackCellphoneformEffectApp(player, lore)
        }
        if (selection == 5) {
            player.runCommand("effect @s night_vision 30 5")
            BlackCellphoneformEffectApp(player, lore)
        }
        if (selection == 6) {
            player.runCommand("effect @s water_breathing 30 5")
            BlackCellphoneformEffectApp(player, lore)
        }
    })
}
//Discraft App
export function BlackCellphoneformDiscraftApp(player, lore) {
    let form = new ModalFormData()
    let playerNameList = Array.from(World.getPlayers(), plr => plr.nameTag)
    form.title(`title.smartphone_discraft` + ` ${lore[2]}%`)
    form.dropdown("text.players_online", playerNameList)
    form.textField("text.message", "text.type_here")
    form.show(player).then((response) => {
        if (response.formValues[1]) {
            if (playerNameList[response.formValues[0]] == player.nameTag) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.you_cant_send_a_message_to_yourself"}]}`)
            }
            if (playerNameList[response.formValues[0]] !== player.nameTag) {
                player.runCommand(`tellraw @s {"rawtext":[{"translate":"text.from_you"},{"text":"§r${playerNameList[response.formValues[0]]}"},{"text":"> "},{"text":"${response.formValues[1]}"}]}`)
                player.runCommand(`tellraw ${playerNameList[response.formValues[0]]} {"rawtext":[{"translate":"text.from"},{"text":" §r${player.nameTag} "},{"translate":"text.to_you"},{"text":"${response.formValues[1]}"}]}`)
                player.runCommand(`execute ${playerNameList[response.formValues[0]]} ~~~ playsound random.notification @s[hasitem={item=smartphone:black_smartphone}, tag=want_notific] ~~~ 1 1`)
                player.runCommand(`execute ${playerNameList[response.formValues[0]]} ~~~ titleraw @s[hasitem={item=smartphone:black_smartphone}, tag=want_notific] actionbar {"rawtext":[{"translate":"text_smartphoneaddon.message"},{"text":"\n"},{"text":" ${player.nameTag} "},{"translate":"text_smartphoneaddon.send_a_message"}]}`)
            }
        }
    })
}
export function BlackCellphoneForm(player, lore) {
    let functions = []
    let actionForm = new ActionFormData()
    actionForm.title(`title.smartphone_home`)
    actionForm.body(`${lore[2]}%`)
    {
        actionForm.button("button.settings_app", "textures/icons_apps/settings.png")
        functions.push(r => {
            BlackCellphoneformSettingsApp(player, lore)
        })
    }
    {
        actionForm.button("button.appstore_app", "textures/icons_apps/app_store.png")
        functions.push(r => {
            BlackCellphoneformAppStoreApp(player, lore)
        })
    }
    if (player.hasTag("store_app")) {
        actionForm.button("button.store_app", "textures/icons_apps/store.png")
        functions.push(r => {
            BlackCellphoneformStoreApp(player, lore)
        })
    }
    if (player.hasTag("bank_app")) {
        actionForm.button("button.bank_app", "textures/icons_apps/bank.png")
        functions.push(r => {
            BlackCellphoneformBankApp(player, lore)
        })
    }
    if (player.hasTag("music_app")) {
        actionForm.button("button.music_app", "textures/icons_apps/music.png")
        functions.push(r => {
            BlackCellphoneformMusicApp(player, lore)
        })
    }
    if (player.hasTag("daynight_app")) {
        actionForm.button("button.daynight_app", "textures/icons_apps/daynight.png")
        functions.push(r => {
            BlackCellphoneformDayNightApp(player, lore)
        })
    }
    if (player.hasTag("weather_app")) {
        actionForm.button("button.weather_app", "textures/icons_apps/weather.png")
        functions.push(r => {
            BlackCellphoneformWeatherApp(player, lore)
        })
    }
    if (player.hasTag("effect_app")) {
        actionForm.button("button.effect_app", "textures/icons_apps/effect.png")
        functions.push(r => {
            BlackCellphoneformEffectApp(player, lore)
        })
    }
    if (player.hasTag("discraft_app")) {
        actionForm.button("button.discraft_app", "textures/icons_apps/discraft.png")
        functions.push(r => {
            BlackCellphoneformDiscraftApp(player, lore)
        })
    }
    actionForm.show(player).then(r => {
        functions[r.selection]()
    })
}