import { world as World } from "@minecraft/server"
import {
    BlackCellphoneForm
} from "./black_smartphone"

World.events.tick.subscribe(() => {
    try {
        for (let sender of World.getPlayers()) {
            let container = sender.getComponent("minecraft:inventory").container
            let item = container.getItem(sender.selectedSlot)
            let durability = item.getComponent("minecraft:durability")
            let currentDurability = durability.damage
            let maximumDurability = durability.maxDurability
            const color_battery = []
            if (currentDurability == 100 || currentDurability == 99 || currentDurability == 98 || currentDurability == 97 || currentDurability == 96 || currentDurability == 95 || currentDurability == 94 || currentDurability == 93 || currentDurability == 92 || currentDurability == 91 ) {
                color_battery.push("§r§c ")
            }
            if (currentDurability == 90 || currentDurability == 89 || currentDurability == 88 || currentDurability == 87 || currentDurability == 86 || currentDurability == 85 || currentDurability == 84 || currentDurability == 83 || currentDurability == 82 || currentDurability == 81 ) {
                color_battery.push("§r§c ")
            }
            if (currentDurability == 80 || currentDurability == 79 || currentDurability == 78 || currentDurability == 77 || currentDurability == 76 || currentDurability == 75 || currentDurability == 74 || currentDurability == 73 || currentDurability == 72 || currentDurability == 71 ) {
                color_battery.push("§r§c ")
            }
            if (currentDurability == 70 || currentDurability == 69 || currentDurability == 68 || currentDurability == 67 || currentDurability == 66 || currentDurability == 65 || currentDurability == 64 || currentDurability == 63 || currentDurability == 62 || currentDurability == 61 ) {
                color_battery.push("§r§e ")
            }
            if (currentDurability == 60 || currentDurability == 59 || currentDurability == 58 || currentDurability == 57 || currentDurability == 56 || currentDurability == 55 || currentDurability == 54 || currentDurability == 53 || currentDurability == 52 || currentDurability == 51 ) {
                color_battery.push("§r§e ")
            }
            if (currentDurability == 50 || currentDurability == 49 || currentDurability == 48 || currentDurability == 47 || currentDurability == 46 || currentDurability == 45 || currentDurability == 44 || currentDurability == 43 || currentDurability == 42 || currentDurability == 41 ) {
                color_battery.push("§r§e ")
            }
            if (currentDurability == 40 || currentDurability == 39 || currentDurability == 38 || currentDurability == 37 || currentDurability == 36 || currentDurability == 35 || currentDurability == 34 || currentDurability == 33 || currentDurability == 32 || currentDurability == 31 ) {
                color_battery.push("§r§a ")
            }
            if (currentDurability == 30 || currentDurability == 29 || currentDurability == 28 || currentDurability == 27 || currentDurability == 26 || currentDurability == 25 || currentDurability == 24 || currentDurability == 23 || currentDurability == 22 || currentDurability == 21 ) {
                color_battery.push("§r§a ")
            }
            if (currentDurability == 20 || currentDurability == 19 || currentDurability == 18 || currentDurability == 17 || currentDurability == 16 || currentDurability == 15 || currentDurability == 14 || currentDurability == 13 || currentDurability == 12 || currentDurability == 11 ) {
                color_battery.push("§r§a ")
            }
            if (currentDurability == 10 || currentDurability == 9 || currentDurability == 8 || currentDurability == 7 || currentDurability == 6 || currentDurability == 5 || currentDurability == 4 || currentDurability == 3 || currentDurability == 2 || currentDurability == 1  || currentDurability == 0) {
                color_battery.push("§r§a ")
            }
            if (item.getLore()[1] == 'undefined') {
                item.setLore([``, `§r§7Owner: Undefined`, `${color_battery}${maximumDurability - currentDurability}` + "%" ])
            } 
            if (item.typeId !== "smartphone:black_smartphone") return
                item.setLore([``, `${item.getLore()[1]}`, `${color_battery}${maximumDurability - currentDurability}` + "%" ])
                container.setItem(sender.selectedSlot, item)
        }
    } catch { }
})
World.events.beforeItemUse.subscribe(({ item, source }) => {
    const player = source
    let lore = item.getLore()
    if (item.typeId !== "smartphone:black_smartphone") return
    if (lore[1] !== `§r§7Owner: Undefined`) {
        if (!lore[1].includes(`${player.nameTag}`)) {
            player.runCommand("titleraw @s actionbar {\"rawtext\":[{\"translate\":\"text.not_your_smartphone\"}]}")
        }
        if (!lore[1].includes(`${player.nameTag}`)) return
        if (item.getComponent('durability').damage == 100) return
        BlackCellphoneForm(player, lore)
    } else {
        item.setLore([``, `§r§7Owner: ${player.nameTag}`])
        BlackCellphoneForm(player, lore)
    }
})