import { world, Vector, system } from "@minecraft/server";
system.run(function ticking() {
    const entities = Array.from(world.getDimension("overworld").getEntities())
    for (const entity of entities) {
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("jump_back")) {
            entity.setVelocity(new Vector(entity.viewVector.x * -0.8, 0.4, entity.viewVector.z * -0.8));
        }
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("jump_forward")) {
            entity.setVelocity(new Vector(entity.viewVector.x * 0.8, 0.85, entity.viewVector.z * 0.8));
        }
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("jump_forward_run")) {
            entity.setVelocity(new Vector(entity.viewVector.x * 0.9, -0.5, entity.viewVector.z * 0.9));
        }
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("attack1")) {
            entity.setVelocity(new Vector(entity.viewVector.x * 0.5, 0, entity.viewVector.z * 0.5));
        }
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("attack3")) {
            entity.setVelocity(new Vector(entity.viewVector.x * -0.5, 0, entity.viewVector.z * -0.5));
        }
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("attack4")) {
            entity.setVelocity(new Vector(entity.viewVector.x * 1.5, 0, entity.viewVector.z * 1.5));
        }
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("move_back")) {
            entity.setVelocity(new Vector(entity.viewVector.x * -0.15, 0, entity.viewVector.z * -0.15));
        }
        if (entity.typeId == 'bd:mommy_long_bd' && entity.hasTag("ram_attack")) {
            entity.setVelocity(new Vector(entity.viewVector.x * 1.2, -1, entity.viewVector.z * 1.2));
        }
    }
    system.run(ticking)
  })