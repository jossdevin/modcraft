import './mommy_long_bd/mommy_move.js'
import './huggy/huggy_move.js'
