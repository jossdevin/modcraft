import { world, Vector, system } from "@minecraft/server";
system.run(function ticking() {
    const entities = Array.from(world.getDimension("overworld").getEntities())
    for (const entity of entities) {
        if (entity.typeId == 'bd:mini_huggy_wuggy_bd' && entity.hasTag("fall_back")) {
            entity.setVelocity(new Vector(entity.viewVector.x * -0.8, -1, entity.viewVector.z * -0.8));
        }
    }
    system.run(ticking)
  })